const generateButton = document.getElementById("generate");
const promptInput = document.getElementById("prompt");
const heightInput = document.getElementById("hInput");
const widthInput = document.getElementById("wInput");
const loadingSpinner = document.getElementById("loading-spinner");
const errorText = document.getElementById("error");
const downloadBtn = document.getElementById("downloadBtn");
const image = document.getElementById("img");
const spinner = document.getElementById("loading-spinner");

document.addEventListener("DOMContentLoaded", function() {

async function fetchImage(urlImage) {

  try {
      const response = await fetch(urlImage);

      if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
      }

      const imageBlob = await response.blob();
      const imageURL = URL.createObjectURL(imageBlob);
      image.style.display = "block";
      image.src = imageURL;
      downloadBtn.href = imageURL;

  } catch (error) {
      console.error('Failed to fetch the image:', error);
      errorText.style.display = "flex";
      errorText.textContent = error;

  }
}

  generateButton.addEventListener("click", function() {
    const description = promptInput.value ?
      encodeURIComponent(promptInput.value) :
      "beautiful%20cat";
    const randomSeed = Math.floor(Math.random() * 10000000);
    const heightImage = heightInput.value ? parseInt(heightInput.value) : 512;
    const widthImage = widthInput.value ? parseInt(widthInput.value) : 512;

    const urlImage = `https://image.pollinations.ai/prompt/${description}?nologo=1&seed=${randomSeed}&height=${heightImage}&width=${widthImage}`;

    promptInput.value = '';
    heightInput.value = '';
    widthInput.value = '';

    fetchImage(urlImage);
  });

});